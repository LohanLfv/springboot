package com.example.dockerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
